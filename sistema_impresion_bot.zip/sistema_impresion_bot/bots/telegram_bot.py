"""
Bot principal de Telegram para el sistema de impresión
"""
import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, filters, ContextTypes
import os
from utils.config_loader import CONFIG
from database.operations import db

# Configurar logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

class TelegramBot:
    def __init__(self):
        self.token = CONFIG['telegram']['bot_token']
        self.application = None
    
    async def start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Mensaje de bienvenida y selección de tipo de cliente"""
        keyboard = [
            [InlineKeyboardButton("👤 Cliente Natural", callback_data="cliente_natural")],
            [InlineKeyboardButton("🏢 Cliente Empresa", callback_data="cliente_empresa")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        welcome_text = (
            "🖨️ Bienvenido al Sistema de Impresión Automatizado\n\n"
            "Por favor, selecciona tu tipo de cliente:"
        )
        
        await update.message.reply_text(
            welcome_text,
            reply_markup=reply_markup
        )
    
    async def handle_button_click(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Manejar clicks en botones"""
        try:
            query = update.callback_query
            await query.answer()
            
            data = query.data
            logger.info(f"Botón presionado: {data}")
            
            if data == "cliente_natural":
                await self.menu_archivos_natural(query, context)
            elif data == "cliente_empresa":
                await self.solicitar_pin_empresa(query, context)
            elif data == "menu_principal":
                await self.menu_principal(query, context)
            elif data.startswith("tipo_"):
                await self.seleccionar_tipo_archivo(query, context, data)
            elif data.startswith("copias_"):
                await self.manejar_seleccion_copias(query, context, data)
            elif data in ["color_bn", "color_color"]:
                await self.manejar_seleccion_color(query, context, data)
            elif data in ["pago_efectivo", "pago_transferencia"]:
                await self.manejar_metodo_pago(query, context, data)
            elif data == "confirmar_pedido":
                await self.confirmar_pedido_final(query, context)
            elif data in ["confirmar_copias", "cancelar_copias"]:
                await self.manejar_confirmacion_copias(query, context, data)
            elif data in ["cambiar_copias", "cambiar_color", "cambiar_metodo"]:
                await self.manejar_cambios(query, context, data)
            else:
                logger.warning(f"Callback no manejado: {data}")
                await query.edit_message_text("❌ Comando no reconocido. Por favor, usa el menú.")
                
        except Exception as e:
            logger.error(f"Error en handle_button_click: {e}")
            try:
                await update.callback_query.message.reply_text(
                    "❌ Error al procesar la solicitud. Por favor, intenta nuevamente."
                )
            except:
                pass
    
    async def seleccionar_tipo_archivo(self, query, context, tipo_archivo):
        """Manejar selección de tipo de archivo"""
        try:
            # Guardar tipo de archivo seleccionado
            context.user_data['tipo_archivo_seleccionado'] = tipo_archivo.replace('tipo_', '')
            context.user_data['esperando_archivo'] = True
            
            tipos = {
                'word': 'Documento Word',
                'pdf': 'Documento PDF', 
                'imagen': 'Imagen (PNG/JPG)',
                'excel': 'Excel'
            }
            
            tipo_nombre = tipos.get(context.user_data['tipo_archivo_seleccionado'], 'archivo')
            
            await query.edit_message_text(
                f"📄 Has seleccionado: {tipo_nombre}\n\n"
                "Por favor, envía el archivo ahora:"
            )
        except Exception as e:
            logger.error(f"Error en seleccionar_tipo_archivo: {e}")
            await query.edit_message_text("❌ Error al procesar la selección. Por favor, intenta nuevamente.")
    
    async def manejar_seleccion_copias(self, query, context, data_copias):
        """Manejar selección de cantidad de copias - CORREGIDO"""
        try:
            from bots.message_handlers import message_handlers
            
            if data_copias == "copias_otra":
                await query.edit_message_text(
                    "🔢 Por favor, escribe la cantidad de copias que necesitas:"
                )
                context.user_data['esperando_copias'] = True
            else:
                copias = int(data_copias.replace('copias_', ''))
                # Pasar directamente el query, no un update
                await message_handlers.handle_copias_selection(query, context, copias)
        except Exception as e:
            logger.error(f"Error en manejar_seleccion_copias: {e}")
            await query.edit_message_text("❌ Error al procesar las copias. Por favor, intenta nuevamente.")
    
    async def manejar_confirmacion_copias(self, query, context, data_confirmacion):
        """Manejar confirmación de copias grandes"""
        try:
            from bots.message_handlers import message_handlers
            
            if data_confirmacion == "confirmar_copias":
                await message_handlers.solicitar_color(query, context)
            else:
                # Cancelar - volver a solicitar copias
                await message_handlers.solicitar_copias(query, context)
        except Exception as e:
            logger.error(f"Error en manejar_confirmacion_copias: {e}")
            await query.edit_message_text("❌ Error al confirmar. Por favor, intenta nuevamente.")
    
    async def manejar_seleccion_color(self, query, context, data_color):
        """Manejar selección de color - CORREGIDO"""
        try:
            from bots.message_handlers import message_handlers
            
            es_color = (data_color == "color_color")
            # Pasar directamente el query, no un update
            await message_handlers.handle_color_selection(query, context, es_color)
        except Exception as e:
            logger.error(f"Error en manejar_seleccion_color: {e}")
            await query.edit_message_text("❌ Error al seleccionar color. Por favor, intenta nuevamente.")
    
    async def manejar_metodo_pago(self, query, context, metodo_pago):
        """Manejar selección de método de pago - CORREGIDO"""
        try:
            from bots.message_handlers import message_handlers
            
            metodo = metodo_pago.replace('pago_', '')
            context.user_data['metodo_pago'] = metodo
            
            if metodo == 'efectivo':
                # Pasar directamente el query
                await message_handlers.confirmar_pedido_natural(query, context)
            else:  # transferencia
                # Pasar directamente el query
                await message_handlers.solicitar_transferencia(query, context)
        except Exception as e:
            logger.error(f"Error en manejar_metodo_pago: {e}")
            await query.edit_message_text("❌ Error al seleccionar método de pago. Por favor, intenta nuevamente.")
    
    async def manejar_cambios(self, query, context, data_cambio):
        """Manejar botones de cambio/retroceso - CORREGIDO"""
        try:
            from bots.message_handlers import message_handlers
            
            if data_cambio == "cambiar_copias":
                # Pasar directamente el query
                await message_handlers.solicitar_copias(query, context)
            elif data_cambio == "cambiar_color":
                # Pasar directamente el query
                await message_handlers.solicitar_color(query, context)
            elif data_cambio == "cambiar_metodo":
                precio_total = context.user_data.get('precio_total', 0)
                # Pasar directamente el query
                await message_handlers.solicitar_metodo_pago(query, context, precio_total)
        except Exception as e:
            logger.error(f"Error en manejar_cambios: {e}")
            await query.edit_message_text("❌ Error al procesar el cambio. Por favor, intenta nuevamente.")
    
    async def confirmar_pedido_final(self, query, context):
        """Confirmar pedido final"""
        try:
            from bots.message_handlers import message_handlers
            
            user_id = query.from_user.id
            pedido_id = await message_handlers.crear_pedido_db(context, user_id, context.user_data.get('metodo_pago'))
            
            if pedido_id:
                tipo_cliente = context.user_data.get('tipo_cliente', 'natural')
                
                if tipo_cliente == 'empresa':
                    await query.edit_message_text(
                        "✅ Pedido confirmado para empresa\n\n"
                        "Tu pedido ha sido añadido a la cola de impresión y se procesará inmediatamente.\n\n"
                        "📞 Te notificaremos cuando esté listo para recoger."
                    )
                else:
                    if context.user_data.get('metodo_pago') == 'efectivo':
                        await query.edit_message_text(
                            "✅ Pedido confirmado\n\n"
                            "Tu pedido ha sido añadido a la cola de impresión.\n"
                            "💰 Método de pago: Efectivo al recoger\n\n"
                            "📞 Te notificaremos cuando esté listo."
                        )
                    else:
                        await query.edit_message_text(
                            "✅ Pedido confirmado\n\n"
                            "Tu pedido ha sido añadido a la cola de impresión.\n"
                            "🏦 Método de pago: Transferencia\n"
                            "📧 Por favor, realiza la transferencia y espera la confirmación.\n\n"
                            "💳 Número de cuenta: 1234-5678-9012-3456"
                        )
            else:
                await query.edit_message_text(
                    "❌ Error al procesar el pedido\n\n"
                    "Por favor, intenta nuevamente o contacta con soporte."
                )
        except Exception as e:
            logger.error(f"Error en confirmar_pedido_final: {e}")
            await query.edit_message_text("❌ Error al confirmar el pedido. Por favor, intenta nuevamente.")
    
    async def solicitar_pin_empresa(self, query, context):
        """Solicitar PIN de empresa"""
        try:
            text = (
                "🏢 Acceso Empresarial\n\n"
                "Por favor, ingresa tu PIN de 4 dígitos:"
            )
            
            # Guardar estado para saber que esperamos PIN
            context.user_data['esperando_pin'] = True
            context.user_data['tipo_cliente'] = 'empresa'
            
            await query.edit_message_text(text)
        except Exception as e:
            logger.error(f"Error en solicitar_pin_empresa: {e}")
            await query.edit_message_text("❌ Error al procesar. Por favor, intenta nuevamente.")
    
    async def menu_archivos_natural(self, query, context):
        """Menú de tipos de archivo para clientes naturales"""
        try:
            keyboard = [
                [InlineKeyboardButton("📄 Documento Word", callback_data="tipo_word")],
                [InlineKeyboardButton("📊 Documento PDF", callback_data="tipo_pdf")],
                [InlineKeyboardButton("🖼️ Imagen (PNG/JPG)", callback_data="tipo_imagen")],
                [InlineKeyboardButton("📊 Excel", callback_data="tipo_excel")],
                [InlineKeyboardButton("🔙 Menú Principal", callback_data="menu_principal")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            text = (
                "👤 Cliente Natural\n\n"
                "Selecciona el tipo de archivo que deseas imprimir:"
            )
            
            context.user_data['tipo_cliente'] = 'natural'
            context.user_data['esperando_archivo'] = False
            
            await query.edit_message_text(
                text,
                reply_markup=reply_markup
            )
        except Exception as e:
            logger.error(f"Error en menu_archivos_natural: {e}")
            await query.edit_message_text("❌ Error al cargar el menú. Por favor, intenta nuevamente.")
    
    async def menu_principal(self, query, context):
        """Volver al menú principal"""
        try:
            keyboard = [
                [InlineKeyboardButton("👤 Cliente Natural", callback_data="cliente_natural")],
                [InlineKeyboardButton("🏢 Cliente Empresa", callback_data="cliente_empresa")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            text = "🖨️ Menú Principal\n\nSelecciona tu tipo de cliente:"
            
            # Limpiar datos de usuario
            context.user_data.clear()
            
            await query.edit_message_text(
                text,
                reply_markup=reply_markup
            )
        except Exception as e:
            logger.error(f"Error en menu_principal: {e}")
            await query.edit_message_text("❌ Error al cargar el menú. Por favor, intenta nuevamente.")
    
    async def handle_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Manejar mensajes de texto"""
        try:
            user_message = update.message.text
            user_id = update.message.from_user.id
            
            # Verificar si estamos esperando PIN de empresa
            if context.user_data.get('esperando_pin'):
                await self.verificar_pin_empresa(update, context, user_message, user_id)
                return
            
            # Verificar si estamos esperando cantidad de copias personalizada
            if context.user_data.get('esperando_copias'):
                try:
                    copias = int(user_message)
                    if copias > 0:
                        from bots.message_handlers import message_handlers
                        context.user_data['esperando_copias'] = False
                        await message_handlers.handle_copias_selection(update, context, copias)
                    else:
                        await update.message.reply_text("❌ Por favor, ingresa un número válido mayor a 0")
                except ValueError:
                    await update.message.reply_text("❌ Por favor, ingresa un número válido")
                return
            
            # Si no es un caso especial, mostrar menú principal
            await self.start(update, context)
        except Exception as e:
            logger.error(f"Error en handle_message: {e}")
            await update.message.reply_text("❌ Error al procesar el mensaje. Por favor, intenta nuevamente.")
    
    async def verificar_pin_empresa(self, update: Update, context: ContextTypes.DEFAULT_TYPE, pin: str, user_id: int):
        """Verificar PIN de empresa"""
        try:
            # Obtener cliente (o crear si no existe)
            cliente = db.obtener_o_crear_cliente(user_id, 'empresa')
            
            # Verificar si está bloqueado
            if cliente.bloqueado_hasta:
                await update.message.reply_text(
                    "❌ Demasiados intentos fallidos. Tu cuenta está bloqueada temporalmente. "
                    "Por favor, intenta nuevamente en 5 minutos."
                )
                return
            
            # Verificar PIN
            empresa = db.verificar_pin_empresa(pin)
            
            if empresa:
                # PIN correcto - resetear intentos y mostrar menú
                db.resetear_intentos(user_id)
                context.user_data['empresa_id'] = empresa.id
                context.user_data['empresa_nombre'] = empresa.nombre
                context.user_data['esperando_pin'] = False
                
                await self.menu_archivos_empresa(update, context, empresa.nombre)
            else:
                # PIN incorrecto - aumentar intentos fallidos
                db.actualizar_intento_fallido(user_id)
                cliente = db.obtener_o_crear_cliente(user_id, 'empresa')
                
                if cliente.intentos_fallidos >= 3:
                    await update.message.reply_text(
                        "❌ Demasiados intentos fallidos. Tu cuenta ha sido bloqueada por 5 minutos."
                    )
                else:
                    intentos_restantes = 3 - cliente.intentos_fallidos
                    await update.message.reply_text(
                        f"❌ PIN incorrecto. Te quedan {intentos_restantes} intentos."
                    )
        except Exception as e:
            logger.error(f"Error en verificar_pin_empresa: {e}")
            await update.message.reply_text("❌ Error al verificar el PIN. Por favor, intenta nuevamente.")
    
    async def menu_archivos_empresa(self, update: Update, context: ContextTypes.DEFAULT_TYPE, empresa_nombre: str):
        """Menú de tipos de archivo para empresas"""
        try:
            keyboard = [
                [InlineKeyboardButton("📄 Documento Word", callback_data="tipo_word")],
                [InlineKeyboardButton("📊 Documento PDF", callback_data="tipo_pdf")],
                [InlineKeyboardButton("🖼️ Imagen (PNG/JPG)", callback_data="tipo_imagen")],
                [InlineKeyboardButton("📊 Excel", callback_data="tipo_excel")],
                [InlineKeyboardButton("🔙 Menú Principal", callback_data="menu_principal")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            text = f"🏢 {empresa_nombre}\n\nSelecciona el tipo de archivo que deseas imprimir:"
            
            context.user_data['esperando_archivo'] = False
            
            await update.message.reply_text(
                text,
                reply_markup=reply_markup
            )
        except Exception as e:
            logger.error(f"Error en menu_archivos_empresa: {e}")
            await update.message.reply_text("❌ Error al cargar el menú. Por favor, intenta nuevamente.")
    
    async def handle_document(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Manejar documentos subidos"""
        try:
            from bots.message_handlers import message_handlers
            await message_handlers.handle_document(update, context)
        except Exception as e:
            logger.error(f"Error en handle_document: {e}")
            await update.message.reply_text("❌ Error al procesar el documento. Por favor, intenta nuevamente.")
    
    async def handle_photo(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Manejar fotos subidas"""
        try:
            from bots.message_handlers import message_handlers
            await message_handlers.handle_photo(update, context)
        except Exception as e:
            logger.error(f"Error en handle_photo: {e}")
            await update.message.reply_text("❌ Error al procesar la imagen. Por favor, intenta nuevamente.")
    
    async def error_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Manejar errores globales"""
        try:
            # Verificar si es un error de timeout (no crítico)
            if hasattr(context.error, '__class__') and context.error.__class__.__name__ == 'TimedOut':
                logger.warning("⚠️ Timeout en operación (puede ignorarse)")
                return
                
            # Loggear el error
            logger.error(f"Error no manejado: {context.error}")
            logger.error(f"Tipo de error: {type(context.error)}")
            
            # Enviar mensaje de error al usuario solo si tenemos un chat válido
            if update:
                try:
                    if hasattr(update, 'callback_query') and update.callback_query:
                        # Es un CallbackQuery
                        await update.callback_query.message.reply_text(
                            "❌ Ocurrió un error inesperado. Por favor, intenta nuevamente."
                        )
                    elif hasattr(update, 'message') and update.message:
                        # Es un Message
                        await update.message.reply_text(
                            "❌ Ocurrió un error inesperado. Por favor, intenta nuevamente."
                        )
                    elif hasattr(update, 'effective_message') and update.effective_message:
                        # Es cualquier tipo de mensaje efectivo
                        await update.effective_message.reply_text(
                            "❌ Ocurrió un error inesperado. Por favor, intenta nuevamente."
                        )
                except Exception as e:
                    logger.error(f"No se pudo enviar mensaje de error: {e}")
                    
        except Exception as e:
            logger.error(f"Error en el manejador de errores: {e}")
    
    def run(self):
        """Iniciar el bot"""
        if not self.token or self.token == "TU_BOT_TOKEN_AQUI":
            logger.error("❌ Token de bot no configurado. Verifica config.yaml o .env")
            return
        
        self.application = Application.builder().token(self.token).build()
        
        # Handlers
        self.application.add_handler(CommandHandler("start", self.start))
        self.application.add_handler(CallbackQueryHandler(self.handle_button_click))
        self.application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, self.handle_message))
        self.application.add_handler(MessageHandler(filters.Document.ALL, self.handle_document))
        self.application.add_handler(MessageHandler(filters.PHOTO, self.handle_photo))
        
        # Manejar errores
        self.application.add_error_handler(self.error_handler)
        
        logger.info("🤖 Bot iniciado...")
        self.application.run_polling()

def main():
    """Función principal para ejecutar el bot"""
    bot = TelegramBot()
    bot.run()

if __name__ == '__main__':
    main()