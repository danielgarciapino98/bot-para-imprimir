"""
Gestión de colas de impresión
"""
import threading
import time
import logging
from queue import Queue
from database.operations import db
from database.models import Pedido

logger = logging.getLogger(__name__)

class QueueManager:
    def __init__(self):
        self.print_queue = Queue()
        self.is_processing = False
        self.current_job = None
        self.lock = threading.Lock()
        
    def add_to_queue(self, pedido_id, telegram_id, tipo_cliente, prioridad=0):
        """Añadir pedido a la cola de impresión"""
        with self.lock:
            item = {
                'pedido_id': pedido_id,
                'telegram_id': telegram_id,
                'tipo_cliente': tipo_cliente,
                'prioridad': prioridad,
                'timestamp': time.time()
            }
            self.print_queue.put(item)
            logger.info(f"Pedido {pedido_id} añadido a la cola")
            
        # Iniciar procesamiento si no está activo
        if not self.is_processing:
            self.start_processing()
    
    def start_processing(self):
        """Iniciar el procesamiento de la cola"""
        if not self.is_processing:
            self.is_processing = True
            processing_thread = threading.Thread(target=self._process_queue)
            processing_thread.daemon = True
            processing_thread.start()
    
    def _process_queue(self):
        """Procesar la cola de impresión (en segundo plano)"""
        while not self.print_queue.empty() or self.is_processing:
            try:
                # Obtener siguiente trabajo (si hay)
                if self.print_queue.empty():
                    time.sleep(1)
                    continue
                
                # Obtener pedido de la cola
                job = self.print_queue.get()
                self.current_job = job
                
                logger.info(f"Procesando pedido {job['pedido_id']}")
                
                # TODO: Aquí se integrará con el sistema de impresión real
                # Por ahora simulamos la impresión
                self._simulate_printing(job)
                
                # Marcar como completado
                self.print_queue.task_done()
                self.current_job = None
                
            except Exception as e:
                logger.error(f"Error procesando cola: {e}")
                self.current_job = None
                time.sleep(5)
        
        self.is_processing = False
    
    def _simulate_printing(self, job):
        """Simular proceso de impresión (placeholder)"""
        try:
            # Simular tiempo de impresión
            time.sleep(2)
            
            # TODO: Reemplazar con impresión real
            logger.info(f"SIMULACIÓN: Imprimiendo pedido {job['pedido_id']}")
            
            # Aquí se integrará con printer_manager para impresión real
            
        except Exception as e:
            logger.error(f"Error en simulación de impresión: {e}")
    
    def get_queue_status(self):
        """Obtener estado actual de la cola"""
        with self.lock:
            queue_size = self.print_queue.qsize()
            current_job = self.current_job
            
            return {
                'en_cola': queue_size,
                'imprimiendo_ahora': current_job,
                'total_pendientes': queue_size + (1 if current_job else 0)
            }
    
    def clear_queue(self):
        """Limpiar la cola de impresión"""
        with self.lock:
            while not self.print_queue.empty():
                try:
                    self.print_queue.get_nowait()
                    self.print_queue.task_done()
                except:
                    pass
            self.current_job = None
            logger.info("Cola de impresión limpiada")

# Instancia global
queue_manager = QueueManager()