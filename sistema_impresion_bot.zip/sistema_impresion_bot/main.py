"""
Sistema de Impresión Automatizado - Punto de Entrada Principal
"""
import os
import sys
import asyncio
import threading

def inicializar_sistema():
    """Inicializar todo el sistema"""
    print("🖨️ Iniciando Sistema de Impresión Automatizado...")
    
    # Asegurar que estamos en el directorio correcto
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    
    # Importar después de cambiar directorio
    from utils.helpers import crear_carpetas_necesarias, backup_database
    from database.setup_database import crear_tablas
    
    # Crear carpetas necesarias
    crear_carpetas_necesarias()
    
    # Crear base de datos
    print("📦 Inicializando base de datos...")
    crear_tablas()
    
    # Crear backup inicial
    print("💾 Creando backup inicial...")
    backup_database()
    
    print("✅ Sistema inicializado correctamente!")

def ejecutar_bot():
    """Ejecutar el bot de Telegram con event loop correcto"""
    try:
        from bots.telegram_bot import TelegramBot
        bot = TelegramBot()
        
        # Crear nuevo event loop para el thread
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        
        bot.run()
    except Exception as e:
        print(f"❌ Error en el bot: {e}")

def ejecutar_sistema_completo():
    """Ejecutar el sistema completo (Bot + Panel)"""
    try:
        # Ejecutar bot en hilo separado
        bot_thread = threading.Thread(target=ejecutar_bot, daemon=True)
        bot_thread.start()
        print("🤖 Bot de Telegram iniciado en segundo plano...")
        
        # Ejecutar panel en hilo principal
        from panel.main_window import MainWindow
        print("🎛️ Iniciando Panel de Control...")
        panel = MainWindow()
        panel.run()
        
    except Exception as e:
        print(f"❌ Error iniciando sistema: {e}")
        input("Presiona Enter para salir...")

if __name__ == '__main__':
    # Ejecutar sistema completo directamente
    inicializar_sistema()
    ejecutar_sistema_completo()