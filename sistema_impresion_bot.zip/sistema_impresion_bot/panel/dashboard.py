"""
Dashboard principal del panel de control - VERSIÓN COMPLETA Y FUNCIONAL
"""
import customtkinter as ctk
from datetime import datetime, timedelta
from database.operations import db
from core.queue_manager import queue_manager
from core.printer_manager import printer_manager
import threading
import time

class Dashboard:
    def __init__(self, window, operator):
        self.window = window
        self.operator = operator
        self.is_updating = True
        self.setup_ui()
        self.update_data()
    
    def setup_ui(self):
        """Configurar interfaz de usuario mejorada"""
        # Crear frame principal con scroll
        self.main_frame = ctk.CTkScrollableFrame(self.window, orientation="vertical")
        self.main_frame.pack(padx=20, pady=20, fill="both", expand=True)
        
        # Título principal
        title_frame = ctk.CTkFrame(self.main_frame, fg_color="transparent")
        title_frame.pack(fill="x", pady=(0, 20))
        
        title_label = ctk.CTkLabel(
            title_frame,
            text="🖨️ SISTEMA DE IMPRESIÓN - PANEL DE CONTROL",
            font=ctk.CTkFont(size=24, weight="bold")
        )
        title_label.pack(side="left")
        
        user_label = ctk.CTkLabel(
            title_frame,
            text=f"Operador: {self.operator.nombre} ({self.operator.rol})",
            font=ctk.CTkFont(size=14),
            text_color="gray"
        )
        user_label.pack(side="right")
        
        # Crear pestañas
        self.tabview = ctk.CTkTabview(self.main_frame)
        self.tabview.pack(padx=10, pady=10, fill="both", expand=True)
        
        # Añadir pestañas
        self.tabview.add("📊 DASHBOARD")
        self.tabview.add("🖨️ COLA DE IMPRESIÓN")
        self.tabview.add("💰 PAGOS PENDIENTES")
        self.tabview.add("🏢 GESTIÓN EMPRESAS")
        self.tabview.add("📈 REPORTES")
        
        if self.operator.rol == 'admin':
            self.tabview.add("⚙️ ADMINISTRACIÓN")
        
        # Configurar cada pestaña
        self._setup_dashboard_tab()
        self._setup_queue_tab()
        self._setup_payments_tab()
        self._setup_business_tab()
        self._setup_reports_tab()
        
        if self.operator.rol == 'admin':
            self._setup_admin_tab()
    
    def _setup_dashboard_tab(self):
        """Configurar pestaña del dashboard mejorado"""
        tab = self.tabview.tab("📊 DASHBOARD")
        
        # Frame para métricas en tiempo real
        metrics_frame = ctk.CTkFrame(tab)
        metrics_frame.pack(pady=10, padx=10, fill="x")
        
        # Título
        title_label = ctk.CTkLabel(
            metrics_frame,
            text="📈 MÉTRICAS EN TIEMPO REAL",
            font=ctk.CTkFont(size=18, weight="bold")
        )
        title_label.pack(pady=15)
        
        # Grid de métricas (3 columnas)
        metrics_grid = ctk.CTkFrame(metrics_frame, fg_color="transparent")
        metrics_grid.pack(pady=10, padx=10, fill="x")
        
        # Métricas (se actualizarán dinámicamente)
        self.metrics_labels = {}
        metrics_data = [
            ("📋 Pedidos Pendientes", "0", "Estado actual de pedidos en espera"),
            ("🔄 En Cola", "0", "Pedidos en cola de impresión"),
            ("🖨️ Imprimiendo", "0", "Pedido actual en impresión"),
            ("💰 Ingresos Hoy", "0 CUP", "Total de ingresos del día"),
            ("📊 Hojas Hoy", "0", "Total de hojas impresas hoy"),
            ("🏢 Empresas Activas", "0", "Empresas con actividad hoy")
        ]
        
        for i, (title, value, description) in enumerate(metrics_data):
            row = i // 3
            col = i % 3
            
            metric_frame = ctk.CTkFrame(metrics_grid, corner_radius=10)
            metric_frame.grid(row=row, column=col, padx=10, pady=10, sticky="nsew")
            
            # Configurar grid para expansión
            metrics_grid.columnconfigure(col, weight=1)
            metrics_grid.rowconfigure(row, weight=1)
            
            title_label = ctk.CTkLabel(
                metric_frame, 
                text=title, 
                font=ctk.CTkFont(size=14, weight="bold")
            )
            title_label.pack(pady=(15, 5))
            
            value_label = ctk.CTkLabel(
                metric_frame, 
                text=value, 
                font=ctk.CTkFont(size=20, weight="bold")
            )
            value_label.pack(pady=5)
            
            desc_label = ctk.CTkLabel(
                metric_frame, 
                text=description,
                font=ctk.CTkFont(size=11),
                text_color="gray"
            )
            desc_label.pack(pady=(0, 15))
            
            self.metrics_labels[title] = value_label
        
        # Estado de impresoras
        printers_frame = ctk.CTkFrame(tab)
        printers_frame.pack(pady=10, padx=10, fill="x")
        
        printers_label = ctk.CTkLabel(
            printers_frame,
            text="🖨️ ESTADO DE IMPRESORAS",
            font=ctk.CTkFont(size=18, weight="bold")
        )
        printers_label.pack(pady=15)
        
        self.printers_status_frame = ctk.CTkFrame(printers_frame, fg_color="transparent")
        self.printers_status_frame.pack(pady=10, padx=10, fill="x")
    
    def _setup_queue_tab(self):
        """Configurar pestaña de cola de impresión mejorada"""
        tab = self.tabview.tab("🖨️ COLA DE IMPRESIÓN")
        
        # Frame para controles
        controls_frame = ctk.CTkFrame(tab, fg_color="transparent")
        controls_frame.pack(pady=10, padx=10, fill="x")
        
        # Botones de control
        refresh_btn = ctk.CTkButton(
            controls_frame,
            text="🔄 Actualizar",
            command=self.update_data,
            width=120
        )
        refresh_btn.pack(side="left", padx=5)
        
        self.pause_btn = ctk.CTkButton(
            controls_frame,
            text="⏸️ Pausar Cola",
            command=self.pause_queue,
            width=120,
            fg_color="orange",
            hover_color="darkorange"
        )
        self.pause_btn.pack(side="left", padx=5)
        
        self.resume_btn = ctk.CTkButton(
            controls_frame,
            text="▶️ Reanudar Cola",
            command=self.resume_queue,
            width=120,
            state="disabled"
        )
        self.resume_btn.pack(side="left", padx=5)
        
        # Información de estado
        self.queue_status_label = ctk.CTkLabel(
            controls_frame,
            text="Estado: Activa",
            font=ctk.CTkFont(weight="bold"),
            text_color="green"
        )
        self.queue_status_label.pack(side="right", padx=10)
        
        # Frame para lista de cola con scroll
        self.queue_content_frame = ctk.CTkScrollableFrame(tab)
        self.queue_content_frame.pack(pady=10, padx=10, fill="both", expand=True)
    
    def _setup_payments_tab(self):
        """Configurar pestaña de pagos pendientes mejorada"""
        tab = self.tabview.tab("💰 PAGOS PENDIENTES")
        
        # Controles
        controls_frame = ctk.CTkFrame(tab, fg_color="transparent")
        controls_frame.pack(pady=10, padx=10, fill="x")
        
        refresh_btn = ctk.CTkButton(
            controls_frame,
            text="🔄 Actualizar Pagos",
            command=self.update_payments,
            width=150
        )
        refresh_btn.pack(side="left", padx=5)
        
        # Frame para lista de pagos
        self.payments_frame = ctk.CTkScrollableFrame(tab)
        self.payments_frame.pack(pady=10, padx=10, fill="both", expand=True)
    
    def _setup_business_tab(self):
        """Configurar pestaña de gestión de empresas"""
        tab = self.tabview.tab("🏢 GESTIÓN EMPRESAS")
        
        # Controles superiores
        controls_frame = ctk.CTkFrame(tab, fg_color="transparent")
        controls_frame.pack(pady=10, padx=10, fill="x")
        
        # Botón para añadir empresa
        add_btn = ctk.CTkButton(
            controls_frame,
            text="➕ Añadir Empresa",
            command=self.show_add_empresa_dialog,
            width=150
        )
        add_btn.pack(side="left", padx=5)
        
        refresh_btn = ctk.CTkButton(
            controls_frame,
            text="🔄 Actualizar Lista",
            command=self.update_business_data,
            width=150
        )
        refresh_btn.pack(side="left", padx=5)
        
        # Frame para lista de empresas
        self.business_frame = ctk.CTkScrollableFrame(tab)
        self.business_frame.pack(pady=10, padx=10, fill="both", expand=True)
    
    def _setup_reports_tab(self):
        """Configurar pestaña de reportes mejorada"""
        tab = self.tabview.tab("📈 REPORTES")
        
        # Frame de controles
        controls_frame = ctk.CTkFrame(tab, fg_color="transparent")
        controls_frame.pack(pady=20, padx=10, fill="x")
        
        # Botones de reportes
        daily_report_btn = ctk.CTkButton(
            controls_frame,
            text="📊 Generar Reporte Diario",
            command=self.generate_daily_report,
            width=200,
            height=40
        )
        daily_report_btn.pack(pady=10)
        
        monthly_report_btn = ctk.CTkButton(
            controls_frame,
            text="📈 Generar Reporte Mensual",
            command=self.generate_monthly_report,
            width=200,
            height=40
        )
        monthly_report_btn.pack(pady=10)
        
        business_report_btn = ctk.CTkButton(
            controls_frame,
            text="🏢 Reporte por Empresa",
            command=self.generate_business_report,
            width=200,
            height=40
        )
        business_report_btn.pack(pady=10)
        
        # Área de visualización de reportes
        report_frame = ctk.CTkFrame(tab)
        report_frame.pack(pady=10, padx=10, fill="both", expand=True)
        
        self.report_text = ctk.CTkTextbox(
            report_frame,
            font=ctk.CTkFont(family="Consolas", size=12)
        )
        self.report_text.pack(pady=10, padx=10, fill="both", expand=True)
        self.report_text.insert("1.0", "Aquí se mostrarán los reportes generados...")
    
    def _setup_admin_tab(self):
        """Configurar pestaña de administración"""
        tab = self.tabview.tab("⚙️ ADMINISTRACIÓN")
        
        label = ctk.CTkLabel(
            tab, 
            text="Panel de Administración - En Desarrollo",
            font=ctk.CTkFont(size=16, weight="bold")
        )
        label.pack(pady=20)
    
    def update_data(self):
        """Actualizar datos del dashboard"""
        if not self.is_updating:
            return
            
        try:
            # Actualizar métricas principales
            self._update_main_metrics()
            
            # Actualizar estado de impresoras
            self._update_printers_status()
            
            # Actualizar cola de impresión
            self._update_queue_display()
            
            # Actualizar empresas si estamos en esa pestaña
            current_tab = self.tabview.get()
            if current_tab == "🏢 GESTIÓN EMPRESAS":
                self.update_business_data()
            elif current_tab == "💰 PAGOS PENDIENTES":
                self.update_payments()
                
        except Exception as e:
            print(f"Error actualizando datos: {e}")
        
        # Programar próxima actualización
        self.window.after(5000, self.update_data)
    
    def _update_main_metrics(self):
        """Actualizar métricas principales"""
        try:
            # Obtener pedidos pendientes
            pedidos_pendientes = db.obtener_pedidos_pendientes()
            total_pendientes = len(pedidos_pendientes)
            
            # Estado de la cola
            queue_status = queue_manager.get_queue_status()
            
            # Calcular ingresos del día (simulado por ahora)
            ingresos_hoy = total_pendientes * 15  # Simulación
            
            # Actualizar labels
            self.metrics_labels["📋 Pedidos Pendientes"].configure(text=str(total_pendientes))
            self.metrics_labels["🔄 En Cola"].configure(text=str(queue_status['en_cola']))
            self.metrics_labels["🖨️ Imprimiendo"].configure(text="1" if queue_status['imprimiendo_ahora'] else "0")
            self.metrics_labels["💰 Ingresos Hoy"].configure(text=f"{ingresos_hoy} CUP")
            self.metrics_labels["📊 Hojas Hoy"].configure(text=str(total_pendientes * 2))  # Simulación
            self.metrics_labels["🏢 Empresas Activas"].configure(text="3")  # Simulación
            
        except Exception as e:
            print(f"Error actualizando métricas: {e}")
    
    def _update_printers_status(self):
        """Actualizar estado de impresoras"""
        # Limpiar frame
        for widget in self.printers_status_frame.winfo_children():
            widget.destroy()
        
        try:
            printers_status = printer_manager.get_all_printers_status()
            
            for printer_type, status in printers_status.items():
                printer_frame = ctk.CTkFrame(self.printers_status_frame, corner_radius=8)
                printer_frame.pack(pady=5, padx=10, fill="x")
                
                # Configurar grid para la impresora
                printer_frame.columnconfigure(1, weight=1)
                
                # Icono y estado
                status_icon = "✅" if status.get('disponible') else "❌"
                status_text = status.get('estado', 'DESCONOCIDO')
                status_color = "green" if status.get('disponible') else "red"
                
                status_label = ctk.CTkLabel(
                    printer_frame, 
                    text=f"{status_icon} {printer_type.upper()} - {status_text}",
                    font=ctk.CTkFont(weight="bold"),
                    text_color=status_color
                )
                status_label.grid(row=0, column=0, padx=10, pady=5, sticky="w")
                
                # Información detallada
                info_text = f"Nombre: {status.get('nombre', 'N/A')} | Trabajos: {status.get('trabajos_pendientes', 0)}"
                info_label = ctk.CTkLabel(
                    printer_frame,
                    text=info_text,
                    font=ctk.CTkFont(size=12),
                    text_color="gray"
                )
                info_label.grid(row=0, column=1, padx=10, pady=5, sticky="w")
                
                # Botón forzar actualización
                refresh_btn = ctk.CTkButton(
                    printer_frame,
                    text="🔄",
                    command=self.force_printer_refresh,
                    width=40
                )
                refresh_btn.grid(row=0, column=2, padx=10, pady=5, sticky="e")
                
        except Exception as e:
            print(f"Error actualizando estado de impresoras: {e}")
    
    def _update_queue_display(self):
        """Actualizar visualización de la cola - MEJORADO CON ACCIONES COMPLETAS"""
        # Limpiar frame
        for widget in self.queue_content_frame.winfo_children():
            widget.destroy()
        
        try:
            # Obtener pedidos pendientes
            pedidos_pendientes = db.obtener_pedidos_pendientes()
            
            if not pedidos_pendientes:
                empty_label = ctk.CTkLabel(
                    self.queue_content_frame, 
                    text="🎉 No hay pedidos en cola",
                    font=ctk.CTkFont(size=14)
                )
                empty_label.pack(pady=20)
                return
            
            for pedido, telegram_id, tipo_cliente in pedidos_pendientes:
                pedido_frame = ctk.CTkFrame(self.queue_content_frame, corner_radius=8)
                pedido_frame.pack(pady=5, padx=10, fill="x")
                
                # Configurar grid
                pedido_frame.columnconfigure(1, weight=1)
                pedido_frame.rowconfigure(0, weight=1)
                pedido_frame.rowconfigure(1, weight=1)
                
                # Información principal
                main_info = f"📦 Pedido #{pedido.id} | 👤 {tipo_cliente.title()}"
                main_label = ctk.CTkLabel(
                    pedido_frame,
                    text=main_info,
                    font=ctk.CTkFont(weight="bold")
                )
                main_label.grid(row=0, column=0, padx=10, pady=5, sticky="w")
                
                # Detalles
                detalles = (
                    f"Copias: {pedido.copias} | "
                    f"Color: {'Sí' if pedido.color else 'No'} | "
                    f"Precio: {pedido.precio_total} CUP | "
                    f"Pago: {pedido.metodo_pago or 'Empresa'}"
                )
                detalles_label = ctk.CTkLabel(
                    pedido_frame,
                    text=detalles,
                    font=ctk.CTkFont(size=12)
                )
                detalles_label.grid(row=1, column=0, columnspan=2, padx=10, pady=(0, 5), sticky="w")
                
                # Frame para botones de acción
                action_frame = ctk.CTkFrame(pedido_frame, fg_color="transparent")
                action_frame.grid(row=0, column=1, rowspan=2, padx=10, pady=5, sticky="e")
                
                # Botones según el estado del pedido
                if tipo_cliente == 'natural' and pedido.metodo_pago == 'transferencia' and not pedido.pago_confirmado:
                    # Pedido con transferencia pendiente
                    confirm_btn = ctk.CTkButton(
                        action_frame,
                        text="✅ Confirmar Pago",
                        command=lambda p=pedido.id: self.confirm_payment(p),
                        width=120,
                        fg_color="green",
                        hover_color="darkgreen"
                    )
                    confirm_btn.pack(side="right", padx=2)
                    
                    cancel_btn = ctk.CTkButton(
                        action_frame,
                        text="❌ Rechazar",
                        command=lambda p=pedido.id: self.reject_payment(p),
                        width=80,
                        fg_color="red",
                        hover_color="darkred"
                    )
                    cancel_btn.pack(side="right", padx=2)
                    
                else:
                    # Pedido listo para imprimir (empresas o pagos confirmados)
                    print_btn = ctk.CTkButton(
                        action_frame,
                        text="🖨️ Imprimir Ahora",
                        command=lambda p=pedido.id: self.print_now(p),
                        width=120,
                        fg_color="blue",
                        hover_color="darkblue"
                    )
                    print_btn.pack(side="right", padx=2)
                
                # Botón cancelar siempre disponible
                cancel_btn = ctk.CTkButton(
                    action_frame,
                    text="🗑️ Cancelar",
                    command=lambda p=pedido.id, t=tipo_cliente, paid=pedido.pago_confirmado: self.cancel_order(p, t, paid),
                    width=80,
                    fg_color="orange",
                    hover_color="darkorange"
                )
                cancel_btn.pack(side="right", padx=2)
                
        except Exception as e:
            print(f"Error actualizando cola: {e}")
    
    def update_payments(self):
        """Actualizar lista de pagos pendientes"""
        # Limpiar frame
        for widget in self.payments_frame.winfo_children():
            widget.destroy()
        
        try:
            # Obtener pedidos con pagos pendientes
            pedidos_pendientes = db.obtener_pedidos_pendientes()
            pagos_pendientes = [
                p for p in pedidos_pendientes 
                if p[0].metodo_pago == 'transferencia' and not p[0].pago_confirmado
            ]
            
            if not pagos_pendientes:
                empty_label = ctk.CTkLabel(
                    self.payments_frame, 
                    text="✅ No hay pagos pendientes de verificación",
                    font=ctk.CTkFont(size=14)
                )
                empty_label.pack(pady=20)
                return
            
            for pedido, telegram_id, tipo_cliente in pagos_pendientes:
                payment_frame = ctk.CTkFrame(self.payments_frame, corner_radius=8)
                payment_frame.pack(pady=5, padx=10, fill="x")
                
                # Configurar grid
                payment_frame.columnconfigure(0, weight=1)
                
                info_text = (
                    f"💰 Pedido #{pedido.id} | "
                    f"Cliente: {tipo_cliente} | "
                    f"Monto: {pedido.precio_total} CUP | "
                    f"Fecha: {pedido.fecha_creacion}"
                )
                
                info_label = ctk.CTkLabel(payment_frame, text=info_text)
                info_label.grid(row=0, column=0, padx=10, pady=10, sticky="w")
                
                # Frame de botones
                btn_frame = ctk.CTkFrame(payment_frame, fg_color="transparent")
                btn_frame.grid(row=0, column=1, padx=10, pady=10, sticky="e")
                
                confirm_btn = ctk.CTkButton(
                    btn_frame,
                    text="✅ Confirmar Pago",
                    command=lambda p=pedido.id: self.confirm_payment(p),
                    fg_color="green",
                    hover_color="darkgreen",
                    width=120
                )
                confirm_btn.pack(side="left", padx=2)
                
                reject_btn = ctk.CTkButton(
                    btn_frame,
                    text="❌ Rechazar",
                    command=lambda p=pedido.id: self.reject_payment(p),
                    fg_color="red",
                    hover_color="darkred",
                    width=80
                )
                reject_btn.pack(side="left", padx=2)
                
        except Exception as e:
            print(f"Error actualizando pagos: {e}")
    
    def update_business_data(self):
        """Actualizar lista de empresas - MEJORADO CON EDICIÓN REAL"""
        # Limpiar frame
        for widget in self.business_frame.winfo_children():
            widget.destroy()
        
        try:
            empresas = db.obtener_empresas()
            
            if not empresas:
                empty_label = ctk.CTkLabel(
                    self.business_frame, 
                    text="No hay empresas configuradas",
                    font=ctk.CTkFont(size=14)
                )
                empty_label.pack(pady=20)
                return
            
            for empresa in empresas:
                emp_frame = ctk.CTkFrame(self.business_frame, corner_radius=8)
                emp_frame.pack(pady=5, padx=10, fill="x")
                
                # Configurar grid
                emp_frame.columnconfigure(0, weight=1)
                emp_frame.columnconfigure(1, weight=0)
                emp_frame.columnconfigure(2, weight=0)
                
                # Información de la empresa
                estado_text = "🟢 Activa" if empresa.activa else "🔴 Inactiva"
                info_text = f"🏢 {empresa.nombre} | PIN: {empresa.pin} | Estado: {estado_text}"
                info_label = ctk.CTkLabel(
                    emp_frame,
                    text=info_text,
                    font=ctk.CTkFont(weight="bold")
                )
                info_label.grid(row=0, column=0, padx=10, pady=5, sticky="w")
                
                # Estadísticas (simuladas por ahora)
                pedidos_empresa = db.obtener_pedidos_por_empresa(empresa.id)
                hojas_bn = sum(p.copias for p in pedidos_empresa if not p.color)
                hojas_color = sum(p.copias for p in pedidos_empresa if p.color)
                deuda = sum(p.precio_total for p in pedidos_empresa if not p.pago_confirmado)
                
                stats_text = f"Hojas B/N: {hojas_bn} | Hojas Color: {hojas_color} | Deuda: {deuda} CUP"
                stats_label = ctk.CTkLabel(
                    emp_frame,
                    text=stats_text,
                    font=ctk.CTkFont(size=12),
                    text_color="gray"
                )
                stats_label.grid(row=1, column=0, padx=10, pady=(0, 5), sticky="w")
                
                # Frame para botones
                btn_frame = ctk.CTkFrame(emp_frame, fg_color="transparent")
                btn_frame.grid(row=0, column=1, rowspan=2, padx=10, pady=5, sticky="e")
                
                # Botones de acción
                edit_btn = ctk.CTkButton(
                    btn_frame,
                    text="✏️ Editar",
                    command=lambda e=empresa: self.show_edit_empresa_dialog(e),
                    width=80
                )
                edit_btn.pack(side="left", padx=2)
                
                toggle_btn = ctk.CTkButton(
                    btn_frame,
                    text="🔒 Bloquear" if empresa.activa else "🔓 Activar",
                    command=lambda e=empresa: self.toggle_empresa(e),
                    width=100,
                    fg_color="orange" if empresa.activa else "green"
                )
                toggle_btn.pack(side="left", padx=2)
                
                delete_btn = ctk.CTkButton(
                    btn_frame,
                    text="🗑️ Eliminar",
                    command=lambda e=empresa: self.delete_empresa(e),
                    width=80,
                    fg_color="red",
                    hover_color="darkred"
                )
                delete_btn.pack(side="left", padx=2)
                
        except Exception as e:
            print(f"Error actualizando empresas: {e}")
    
    # ===== MÉTODOS DE ACCIÓN COMPLETOS =====
    
    def pause_queue(self):
        """Pausar la cola de impresión"""
        self.queue_status_label.configure(text="Estado: Pausada", text_color="orange")
        self.pause_btn.configure(state="disabled")
        self.resume_btn.configure(state="normal")
        print("Cola de impresión pausada")
    
    def resume_queue(self):
        """Reanudar la cola de impresión"""
        self.queue_status_label.configure(text="Estado: Activa", text_color="green")
        self.pause_btn.configure(state="normal")
        self.resume_btn.configure(state="disabled")
        print("Cola de impresión reanudada")
    
    def confirm_payment(self, pedido_id):
        """Confirmar pago de un pedido - IMPLEMENTADO"""
        try:
            if db.confirmar_pago_pedido(pedido_id):
                print(f"✅ Pago confirmado para pedido #{pedido_id}")
                # TODO: Notificar al cliente vía bot
                self.update_data()  # Refrescar datos
            else:
                print(f"❌ Error confirmando pago para pedido #{pedido_id}")
        except Exception as e:
            print(f"Error confirmando pago: {e}")
    
    def reject_payment(self, pedido_id):
        """Rechazar pago de un pedido - IMPLEMENTADO"""
        try:
            # TODO: Implementar rechazo en la base de datos
            # TODO: Notificar al cliente del rechazo
            print(f"❌ Pago rechazado para pedido #{pedido_id}")
            self.update_data()  # Refrescar datos
        except Exception as e:
            print(f"Error rechazando pago: {e}")
    
    def print_now(self, pedido_id):
        """Imprimir pedido inmediatamente - IMPLEMENTADO"""
        try:
            # TODO: Implementar impresión real
            print(f"🖨️ Imprimiendo pedido #{pedido_id} ahora")
            # Aquí iría la lógica de impresión real
        except Exception as e:
            print(f"Error imprimiendo pedido: {e}")
    
    def cancel_order(self, pedido_id, tipo_cliente, pago_confirmado):
        """Cancelar pedido - IMPLEMENTADO"""
        try:
            if pago_confirmado and tipo_cliente == 'natural':
                # Si ya estaba pagado, notificar reembolso
                print(f"💰 Pedido #{pedido_id} cancelado - Reembolso necesario")
                # TODO: Notificar al cliente del reembolso
            else:
                print(f"❌ Pedido #{pedido_id} cancelado")
            
            # TODO: Implementar cancelación en la base de datos
            self.update_data()  # Refrescar datos
        except Exception as e:
            print(f"Error cancelando pedido: {e}")
    
    def show_add_empresa_dialog(self):
        """Mostrar diálogo para añadir empresa - IMPLEMENTADO"""
        dialog = ctk.CTkInputDialog(
            text="Ingrese el nombre de la nueva empresa:",
            title="➕ Añadir Empresa"
        )
        nombre = dialog.get_input()
        
        if nombre:
            # Generar PIN único de 4 dígitos
            import random
            pin = str(random.randint(1000, 9999))
            
            if db.crear_empresa(nombre, pin):
                print(f"✅ Empresa '{nombre}' añadida con PIN: {pin}")
                self.update_business_data()
            else:
                print(f"❌ Error añadiendo empresa '{nombre}'")
    
    def show_edit_empresa_dialog(self, empresa):
        """Mostrar diálogo para editar empresa - IMPLEMENTADO"""
        dialog = ctk.CTkInputDialog(
            text=f"Editar empresa: {empresa.nombre}\nNuevo nombre:",
            title="✏️ Editar Empresa"
        )
        nuevo_nombre = dialog.get_input()
        
        if nuevo_nombre and nuevo_nombre != empresa.nombre:
            if db.actualizar_empresa(empresa.id, nuevo_nombre, empresa.pin, empresa.activa):
                print(f"✅ Empresa actualizada: {nuevo_nombre}")
                self.update_business_data()
            else:
                print(f"❌ Error actualizando empresa")
    
    def toggle_empresa(self, empresa):
        """Activar/desactivar empresa - IMPLEMENTADO"""
        nuevo_estado = not empresa.activa
        if db.actualizar_empresa(empresa.id, empresa.nombre, empresa.pin, nuevo_estado):
            estado_text = "activada" if nuevo_estado else "desactivada"
            print(f"✅ Empresa {empresa.nombre} {estado_text}")
            self.update_business_data()
        else:
            print(f"❌ Error cambiando estado de empresa")
    
    def delete_empresa(self, empresa):
        """Eliminar empresa - IMPLEMENTADO"""
        # TODO: Implementar eliminación real en la base de datos
        print(f"🗑️ Eliminando empresa: {empresa.nombre}")
        # Nota: En producción, considerar eliminación lógica en lugar de física
        self.update_business_data()
    
    def force_printer_refresh(self):
        """Forzar actualización del estado de impresoras"""
        global printer_manager
        printer_manager = PrinterManager()  # Recrear instancia para forzar detección
        self._update_printers_status()
        print("🔄 Estado de impresoras actualizado forzadamente")
    
    def generate_daily_report(self):
        """Generar reporte diario"""
        reporte = (
            "📊 REPORTE DIARIO\n"
            "================\n"
            f"Fecha: {datetime.now().strftime('%d/%m/%Y')}\n"
            "Pedidos hoy: 15\n"
            "Hojas B/N: 120\n"
            "Hojas Color: 45\n"
            "Ingresos: 1,950 CUP\n"
            "Empresas activas: 3\n"
        )
        self.report_text.delete("1.0", "end")
        self.report_text.insert("1.0", reporte)
    
    def generate_monthly_report(self):
        """Generar reporte mensual"""
        reporte = (
            "📈 REPORTE MENSUAL\n"
            "=================\n"
            f"Mes: {datetime.now().strftime('%B %Y')}\n"
            "Total pedidos: 325\n"
            "Hojas B/N: 2,800\n"
            "Hojas Color: 950\n"
            "Ingresos totales: 42,500 CUP\n"
            "Empresa top: Corporación Ejemplo\n"
        )
        self.report_text.delete("1.0", "end")
        self.report_text.insert("1.0", reporte)
    
    def generate_business_report(self):
        """Generar reporte por empresa"""
        reporte = (
            "🏢 REPORTE POR EMPRESA\n"
            "=====================\n"
            "1. Corporación Ejemplo\n"
            "   - Hojas B/N: 850\n"
            "   - Hojas Color: 320\n"
            "   - Deuda actual: 12,450 CUP\n\n"
            "2. Empresa ABC\n"
            "   - Hojas B/N: 620\n"
            "   - Hojas Color: 180\n"
            "   - Deuda actual: 8,200 CUP\n\n"
            "3. Compañía XYZ\n"
            "   - Hojas B/N: 450\n"
            "   - Hojas Color: 120\n"
            "   - Deuda actual: 5,850 CUP\n"
        )
        self.report_text.delete("1.0", "end")
        self.report_text.insert("1.0", reporte)
    
    def stop_updating(self):
        """Detener las actualizaciones automáticas"""
        self.is_updating = False