"""
Ventana de login para operadores - VERSIÓN CORREGIDA
"""
import customtkinter as ctk
from core.auth_manager import auth_manager

class LoginWindow:
    def __init__(self, on_login_success):
        self.on_login_success = on_login_success
        self.window = None
        
    def show(self):
        """Mostrar ventana de login"""
        # Configurar apariencia primero
        ctk.set_appearance_mode("System")
        ctk.set_default_color_theme("blue")
        
        self.window = ctk.CTk()
        self.window.title("Sistema de Impresión - Login")
        self.window.geometry("400x350")
        self.window.resizable(False, False)
        
        # Centrar en pantalla
        self._center_window()
        
        # Crear interfaz
        self._create_widgets()
        
        self.window.mainloop()
    
    def _center_window(self):
        """Centrar ventana en pantalla"""
        self.window.update_idletasks()
        width = 400
        height = 350
        x = (self.window.winfo_screenwidth() // 2) - (width // 2)
        y = (self.window.winfo_screenheight() // 2) - (height // 2)
        self.window.geometry(f'{width}x{height}+{x}+{y}')
    
    def _create_widgets(self):
        """Crear widgets de la interfaz - VERSIÓN CORREGIDA"""
        # Frame principal con padding
        main_frame = ctk.CTkFrame(self.window, fg_color="transparent")
        main_frame.pack(pady=40, padx=40, fill="both", expand=True)
        
        # Título
        title_label = ctk.CTkLabel(
            main_frame, 
            text="🖨️ Sistema de Impresión",
            font=ctk.CTkFont(size=22, weight="bold")
        )
        title_label.pack(pady=(0, 10))
        
        # Subtítulo
        subtitle_label = ctk.CTkLabel(
            main_frame,
            text="Panel de Operadores",
            font=ctk.CTkFont(size=14),
            text_color="gray"
        )
        subtitle_label.pack(pady=(0, 30))
        
        # Frame para campos de entrada
        input_frame = ctk.CTkFrame(main_frame, fg_color="transparent")
        input_frame.pack(fill="x", pady=10)
        
        # Campo de usuario
        user_label = ctk.CTkLabel(input_frame, text="Usuario:", anchor="w")
        user_label.pack(fill="x", pady=(0, 5))
        
        self.user_entry = ctk.CTkEntry(
            input_frame, 
            placeholder_text="Ingresa tu usuario",
            height=40
        )
        self.user_entry.pack(fill="x", pady=(0, 15))
        
        # Campo de contraseña
        password_label = ctk.CTkLabel(input_frame, text="Contraseña:", anchor="w")
        password_label.pack(fill="x", pady=(0, 5))
        
        self.password_entry = ctk.CTkEntry(
            input_frame, 
            placeholder_text="Ingresa tu contraseña",
            show="•",  # Usar bullet point en lugar de asterisco
            height=40
        )
        self.password_entry.pack(fill="x", pady=(0, 20))
        
        # Botón de login
        login_button = ctk.CTkButton(
            input_frame,
            text="Iniciar Sesión",
            command=self._login,
            height=40,
            font=ctk.CTkFont(size=14, weight="bold")
        )
        login_button.pack(fill="x", pady=10)
        
        # Etiqueta de estado
        self.status_label = ctk.CTkLabel(
            input_frame, 
            text="", 
            text_color="red",
            font=ctk.CTkFont(size=12)
        )
        self.status_label.pack(pady=5)
        
        # Información de credenciales por defecto
        info_label = ctk.CTkLabel(
            input_frame,
            text="Usuario: admin | Contraseña: admin123",
            text_color="blue",
            font=ctk.CTkFont(size=11)
        )
        info_label.pack(pady=(10, 0))
        
        # Eventos de teclado
        self.window.bind('<Return>', lambda event: self._login())
        self.password_entry.bind('<Return>', lambda event: self._login())
        
        # Focus en usuario
        self.user_entry.focus()
    
    def _login(self):
        """Manejar intento de login"""
        username = self.user_entry.get().strip()
        password = self.password_entry.get().strip()
        
        if not username:
            self.status_label.configure(text="❌ Por favor, ingresa el usuario")
            self.user_entry.focus()
            return
            
        if not password:
            self.status_label.configure(text="❌ Por favor, ingresa la contraseña")
            self.password_entry.focus()
            return
        
        # Mostrar loading
        self.status_label.configure(text="⏳ Verificando credenciales...", text_color="blue")
        self.window.update()
        
        # Autenticar
        operator, message = auth_manager.authenticate_operator(username, password)
        
        if operator:
            self.status_label.configure(text="✅ Login exitoso", text_color="green")
            self.window.after(800, lambda: self._on_login_success(operator))
        else:
            self.status_label.configure(text=f"❌ {message}")
            self.password_entry.delete(0, 'end')
            self.password_entry.focus()
    
    def _on_login_success(self, operator):
        """Manejar login exitoso"""
        self.window.destroy()
        self.on_login_success(operator)