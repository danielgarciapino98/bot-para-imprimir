"""
Ventana principal del panel de control - VERSIÓN MEJORADA
"""
import customtkinter as ctk
from .login_window import LoginWindow
from .dashboard import Dashboard

class MainWindow:
    def __init__(self):
        self.window = None
        self.current_operator = None
        self.dashboard = None
        
    def run(self):
        """Ejecutar la aplicación del panel"""
        # Configurar apariencia de customtkinter
        ctk.set_appearance_mode("System")
        ctk.set_default_color_theme("blue")
        
        # Mostrar ventana de login
        login_window = LoginWindow(self.on_login_success)
        login_window.show()
    
    def on_login_success(self, operator):
        """Manejar login exitoso"""
        self.current_operator = operator
        self.show_dashboard()
    
    def show_dashboard(self):
        """Mostrar el dashboard principal mejorado"""
        self.window = ctk.CTk()
        
        # Configurar ventana principal
        self.window.title("Sistema de Impresión - Panel de Control")
        self.window.geometry("1400x800")  # Tamaño más grande
        self.window.minsize(1200, 700)    # Tamaño mínimo
        
        # Centrar ventana
        self._center_window()
        
        self.dashboard = Dashboard(self.window, self.current_operator)
        
        # Manejar cierre de ventana
        self.window.protocol("WM_DELETE_WINDOW", self.on_close)
        
        self.window.mainloop()
    
    def _center_window(self):
        """Centrar ventana en pantalla"""
        self.window.update_idletasks()
        width = 1400
        height = 800
        x = (self.window.winfo_screenwidth() // 2) - (width // 2)
        y = (self.window.winfo_screenheight() // 2) - (height // 2)
        self.window.geometry(f'{width}x{height}+{x}+{y}')
    
    def on_close(self):
        """Manejar cierre de la aplicación"""
        if self.window:
            self.window.destroy()
        print("Panel de control cerrado")